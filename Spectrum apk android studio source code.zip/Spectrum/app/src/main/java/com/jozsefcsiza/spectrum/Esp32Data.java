package com.jozsefcsiza.spectrum;

public class Esp32Data {
    public static int DisplayTime = 1;
    public static int Brightness = 2;
    public static int Gain = 30;
    public static int Squelch = 0;

    static void DefaultValues() {
        DisplayTime = 1;
        Brightness = 2;
        Gain = 30;
        Squelch = 0;
    }
}
