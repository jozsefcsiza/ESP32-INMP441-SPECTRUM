package com.jozsefcsiza.spectrum;

import android.app.Dialog;
import android.bluetooth.BluetoothDevice;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

public class SelectBluetooth extends MainActivity{
    static int touchColor = Color.LTGRAY, textColor = Color.rgb(75,75,75), moveY;
    static Dialog selectDialog;
    static List<BluetoothDevice> btDevices;
    static void ShowAvailabelDevices() {
        btDevices= myBluetooth.getBtDevices();
        if (btDevices.size() > 0) {
            selectDialog = new Dialog(context);
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);
            final View view2 = inflater.inflate(R.layout.selectbt, null);
            selectDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            selectDialog.setContentView(view2);
            selectDialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));

            selectDialog.getWindow().setLayout(displayWidth / 2 + displayWidth / 3, WindowManager.LayoutParams.WRAP_CONTENT);

            final ScrollView btScrollView = (ScrollView) selectDialog.findViewById(R.id.btscrollView);
            btScrollView.setBackgroundColor(mainBackColor);

            LinearLayout.LayoutParams layoutparams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutparams.gravity = Gravity.CENTER;

            LinearLayout btLayout  = new LinearLayout(context);
            btScrollView.addView(btLayout, layoutparams);
            btLayout.setOrientation(LinearLayout.VERTICAL);
            btLayout.setBackgroundColor(Color.WHITE);
            btLayout.setGravity(Gravity.CENTER);

            for(BluetoothDevice device : btDevices)
            {
                int h = (int)(55 * density);
                float textSize = 7f * density;
                TextView tView = new TextView(context);
                LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h);
                lLParams.gravity = Gravity.CENTER;

                btLayout.addView(tView, lLParams);
                tView.setGravity(Gravity.CENTER);
                tView.setTextSize(textSize);
                tView.setTextColor(textColor);
                tView.setText(device.getName());

                setOntouchListener(tView, device);
            }

            selectDialog.show();
        } else {
            Toast.makeText(context,"No bluetooth devices available", Toast.LENGTH_SHORT).show();
        }
    }

    static void setOntouchListener (final TextView tView, final BluetoothDevice device)
    {
        tView.setOnTouchListener (new View.OnTouchListener()
        {
            public boolean onTouch(View v, MotionEvent event)
            {

                int action = event.getAction();
                switch (action)
                {

                    case MotionEvent.ACTION_DOWN:
                        tView.setBackgroundColor(touchColor);
                        int[] loc = new int[2];

                        break;

                    case MotionEvent.ACTION_UP:

                        moveY = (int) event.getRawY();
                        loc = new int[2];
                        v.getLocationOnScreen(loc);

                        tView.setBackground(null);

                        if ((loc[1] <= moveY) && (moveY <= loc[1] + v.getHeight()))
                        {
                            try {
                                myBluetooth.closeBT();
                            } catch (Exception e) { };

                            myBluetooth.mmDevice = device;
                            MyBluetooth.btName = myBluetooth.mmDevice.getName();
                            SharedPreferences.Editor editor = mPrefs.edit();
                            editor.putString(MPREFS_BLUETOOTH_NAME, MyBluetooth.btName);
                            editor.commit();
                            try {
                                myBluetooth.openBT();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            selectDialog.dismiss();
                        }

                        break;

                    case MotionEvent.ACTION_MOVE:

                        moveY = (int) event.getRawY();
                        loc = new int[2];
                        v.getLocationOnScreen(loc);

                        if ((loc[1] > moveY) || (moveY > loc[1] + v.getHeight()))
                        {
                            tView.setBackground(null);
                        }

                        break;

                    case MotionEvent.ACTION_CANCEL:
                        tView.setBackground(null);
                        break;
                }

                return true;
            }
        });
    }
}
