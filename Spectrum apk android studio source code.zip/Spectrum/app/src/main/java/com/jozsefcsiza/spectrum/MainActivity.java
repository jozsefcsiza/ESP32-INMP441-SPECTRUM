package com.jozsefcsiza.spectrum;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.preference.PreferenceManager;
import android.view.Display;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.io.IOException;

public class MainActivity extends Activity {

    static String BT_SPECTRUM_NEXT_PATTERN =	"snp";
    static String BT_SPECTRUM_AUTO_PATTERN =	"sap";
    static String BT_SPECTRUM_BRIGHTNESS =		"sbr";
    static String BT_SPECTRUM_GAIN =			"sga";
    static String BT_SPECTRUM_SQUELCH =		    "ssq";
    static String BT_SPECTRUM_RESET =			"srs";

    static String BT_GET_ESP_DATA =             "esp";
    static String MPREFS_BLUETOOTH_NAME =       "BluetoothName";
    static Vibrator mVibrator;
    static int VIBRATE_DURATION = 5;

    static int displayWidth, displayHeight;
    static int mainBackColor = Color.rgb(0, 151, 230), spectrumBackgroundColor = Color.rgb(140, 122, 230), mainTextColor = Color.WHITE;
    static float density;
    static RelativeLayout mainRelativeLayout;
    static LinearLayout mainMenuLayout, spectrumLayout;
    static Context context;
    static MyBluetooth myBluetooth;
    static SharedPreferences mPrefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = MainActivity.this;
        mPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        MyBluetooth.btName = mPrefs.getString(MPREFS_BLUETOOTH_NAME,"");
        mVibrator = (Vibrator) this.getSystemService(Context.VIBRATOR_SERVICE);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);
        setContentView(R.layout.activity_main);
        mainRelativeLayout = findViewById(R.id.mainRelativeLayout);
        mainRelativeLayout.setBackgroundColor(mainBackColor);
        density = getResources().getDisplayMetrics().density;
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        displayWidth = size.x;
        displayHeight = size.y;
        SetNavigationBarColor(mainBackColor);
        setStatusBarColor(mainBackColor);
        MainMenu.DrawMainMenu();
    }

    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (spectrumLayout != null) {
                try
                {
                    mainRelativeLayout.removeView(spectrumLayout);
                } catch (Exception e) {};
                spectrumLayout = null;
                MainMenu.DrawMainMenu();
            } else {
                finish();
            }
        }
        return true;
    }

    @Override
    public void onDestroy()
    {
        try {
            myBluetooth.closeBT();
        } catch (Exception e) { };
        super.onDestroy();
    }

    @Override
    public void onPause()
    {
        try {
            myBluetooth.closeBT();
        } catch (Exception e) { };
        super.onPause();
    }

    @Override
    public void onResume()
    {
        myBluetooth = new MyBluetooth();
        myBluetooth.findBT(MyBluetooth.btName);
        try {
            myBluetooth.openBT();
        } catch (IOException e) {
            e.printStackTrace();
        }
        super.onResume();
    }

    static void setStatusBarColor(int color)
    {
        Window window = ((Activity)context).getWindow();
        window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
        {
            try
            {
                window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
                window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
                window.setStatusBarColor(color);
            }
            catch (Exception e) {}
        }
    }

    static void SetNavigationBarColor(int color)
    {
        try {
            ((Activity)context).getWindow().setNavigationBarColor(color);
        } catch (Exception E) {};
    }

    static void Vibrate() {
        try {
            mVibrator.vibrate(VibrationEffect.createOneShot(VIBRATE_DURATION, VibrationEffect.DEFAULT_AMPLITUDE));
        } catch (Exception e){
            mVibrator.vibrate(VIBRATE_DURATION);
        }
    }
}