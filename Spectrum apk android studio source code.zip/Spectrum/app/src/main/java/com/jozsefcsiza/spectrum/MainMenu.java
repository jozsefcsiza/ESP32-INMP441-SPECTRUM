package com.jozsefcsiza.spectrum;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.IOException;

public class MainMenu extends MainActivity{
    static int w, h, touchColor = Color.rgb(113, 128, 147), downY, moveY;
    static GradientDrawable buttonDrawable, touchDrawable;

    static void DrawMainMenu() {
        w = (int)(displayWidth / 1.25);
        h = (int)(60 * density);
        CreateDrawables();
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);
        params.leftMargin = 0;
        params.topMargin = 0;

        mainMenuLayout = new LinearLayout(context);
        mainRelativeLayout.addView(mainMenuLayout, params);
        mainMenuLayout.setBackgroundColor(mainBackColor);
        mainMenuLayout.setGravity(Gravity.CENTER);
        mainMenuLayout.setOrientation(LinearLayout.VERTICAL);

        DrawMenuElement("SPECTRUM SETTINGS", "s");
        DrawSpacer();
        DrawMenuElement("SELECT BLUETOOTH", "b");
        DrawSpacer();
        DrawMenuElement("ESP32 DEEP SLEEP", "d");

        SetNavigationBarColor(mainBackColor);
        setStatusBarColor(mainBackColor);
    }

    static void DrawMenuElement(String text, String tag) {
        float textSize = 7.5f * density;
        TextView tView = new TextView(context);
        LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(w, h);
        lLParams.gravity = Gravity.CENTER;

        mainMenuLayout.addView(tView, lLParams);
        tView.setGravity(Gravity.CENTER);
        tView.setBackground(buttonDrawable);
        tView.setTextSize(textSize);
        tView.setTextColor(mainTextColor);
        tView.setText(text);

        SetontouchListener(tView, tag);
    }

    static void DrawSpacer() {
        TextView tView = new TextView(context);
        LinearLayout.LayoutParams lLParams = new LinearLayout.LayoutParams(w, h / 2);
        lLParams.gravity = Gravity.CENTER;

        mainMenuLayout.addView(tView, lLParams);
    }

    static void CreateDrawables() {
        float radius = h / 4.0f;
        buttonDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {Color.TRANSPARENT, Color.TRANSPARENT});
        buttonDrawable.setCornerRadii(
                new float[] {
                        radius, radius,
                        radius, radius,
                        radius, radius,
                        radius, radius});
        buttonDrawable.setStroke((int)(0.5 * density), mainTextColor);

        touchDrawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[] {touchColor, touchColor});
        touchDrawable.setCornerRadii(
                new float[] {
                        radius, radius,
                        radius, radius,
                        radius, radius,
                        radius, radius});
        touchDrawable.setStroke((int)(0.5 * density), mainTextColor);
    }

    static void SetontouchListener (final TextView textView, final String tag)
    {
        textView.setOnTouchListener (new View.OnTouchListener()
        {
            public boolean onTouch(View v, MotionEvent event) {

                int action = event.getAction();
                switch (action){
                    case MotionEvent.ACTION_DOWN:
                        downY = (int) event.getRawY();
                        textView.setBackground(null);
                        textView.setBackground(touchDrawable);
                        Vibrate();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        moveY = (int) event.getRawY();
                        break;
                    case MotionEvent.ACTION_UP:
                        textView.setBackground(null);
                        textView.setBackground(buttonDrawable);
                        if (Math.abs(moveY - downY) < h / 2) {
                            if (tag.equals("s")) {
                                try {
                                    mainRelativeLayout.removeView(mainMenuLayout);
                                } catch (Exception e) {
                                }
                                ;
                                mainMenuLayout = null;
                                Spectrum.DrawSpectrumSettings();
                            } else if (tag.equals("b")) {
                                SelectBluetooth.ShowAvailabelDevices();
                            } else if (tag.equals("d")) {
                                try {
                                    myBluetooth.write(BT_ESP_DEEP_SLEEP);
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                        break;
                    case MotionEvent.ACTION_CANCEL:
                        textView.setBackground(null);
                        textView.setBackground(buttonDrawable);
                        break;
                }
                return true;
            }
        });
    }
}
