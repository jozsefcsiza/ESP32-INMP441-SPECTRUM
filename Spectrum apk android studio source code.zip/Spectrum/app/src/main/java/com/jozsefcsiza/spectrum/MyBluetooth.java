package com.jozsefcsiza.spectrum;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class MyBluetooth extends MainActivity{
    static String btName = "";
    static BluetoothAdapter mBluetoothAdapter;
    static BluetoothSocket mmSocket;
    static BluetoothDevice mmDevice;
    static OutputStream outputStream;
    static InputStream inStream;
    static Thread workerThread;
    static byte[] readBuffer;
    static int readBufferPosition;
    static volatile boolean stopWorker;
    static Toast toast;

    public List<BluetoothDevice> getBtDevices() {
        List<BluetoothDevice> btDevices = new ArrayList<>();
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null)
        {
            Toast.makeText(context,"No bluetooth adapter available", Toast.LENGTH_SHORT).show();
        }

        if(!mBluetoothAdapter.isEnabled())
        {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            ((Activity)context).startActivityForResult(enableBluetooth, 0);
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                btDevices.add(device);
            }
        }
        return btDevices;
    }

    public void findBT(String blueToothName)
    {
        mmDevice = null;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if(mBluetoothAdapter == null)
        {
            Toast.makeText(context,"No bluetooth adapter available", Toast.LENGTH_SHORT).show();
        }

        if(!mBluetoothAdapter.isEnabled())
        {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            ((Activity)context).startActivityForResult(enableBluetooth, 0);
        }

        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                if(device.getName().equals(blueToothName))
                {
                    Toast.makeText(context,"Connected to: " + blueToothName, Toast.LENGTH_SHORT).show();
                    mmDevice = device;
                    break;
                }
            }
        }
    }

    public void openBT() throws IOException
    {
        if (mmDevice != null) {
            UUID uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"); //Standard SerialPortService ID
            mmSocket = mmDevice.createRfcommSocketToServiceRecord(uuid);
            mmSocket.connect();
            outputStream = mmSocket.getOutputStream();
            inStream = mmSocket.getInputStream();

            beginListenForData();

            Toast.makeText(context, "Bluetooth opened: " + btName, Toast.LENGTH_SHORT).show();

            SharedPreferences.Editor editor = mPrefs.edit();
            editor.putString(MPREFS_BLUETOOTH_NAME, mmDevice.getName());
            editor.commit();

            try {
                myBluetooth.write(BT_GET_ESP_DATA);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    void closeBT() throws IOException
    {
        stopWorker = true;
        outputStream.close();
        inStream.close();
        mmSocket.close();
    }

    static void beginListenForData()
    {
        final Handler handler = new Handler();
        final byte delimiter = 10; //This is the ASCII code for a newline character

        stopWorker = false;
        readBufferPosition = 0;
        readBuffer = new byte[1024];
        workerThread = new Thread(new Runnable()
        {
            public void run()
            {
                while(!Thread.currentThread().isInterrupted() && !stopWorker)
                {
                    try
                    {
                        int bytesAvailable = inStream.available();
                        if(bytesAvailable > 0)
                        {
                            byte[] packetBytes = new byte[bytesAvailable];
                            inStream.read(packetBytes);
                            String data = new String(packetBytes, "US-ASCII");
                            data.trim();
                            if (!data.equals("")) {
                                handler.post(new Runnable() {
                                    public void run() {
                                        //Toast.makeText(context, "Bluetooth data: " + data, Toast.LENGTH_SHORT).show();
                                        try {
                                            checkBtData(data);
                                        } catch (Exception e) {Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();};
                                    }
                                });
                            }
                        }
                    }
                    catch (IOException ex)
                    {
                        stopWorker = true;
                    }
                }
            }
        });

        workerThread.start();
    }

    static void checkBtData(String data) {
        char[] charArray = data.toCharArray();
        if (charArray.length >= 3) {
            String tag = "";
            tag = tag + charArray[0] + charArray[1] + charArray[2]; //The first three chars should be the bluetooth tag
            if (tag.equals(BT_SPECTRUM_BRIGHTNESS)) {
                try
                {
                    int value = Integer.parseInt(getNumberInStringFormat(charArray));
                    Esp32Data.Brightness = value;
                } catch (Exception e) {};
            } else if (tag.equals(BT_SPECTRUM_GAIN)) {
                try
                {
                    int value = Integer.parseInt(getNumberInStringFormat(charArray));
                    Esp32Data.Gain = value;
                } catch (Exception e) {};
            } else if (tag.equals(BT_SPECTRUM_SQUELCH)) {
                try
                {
                    int value = Integer.parseInt(getNumberInStringFormat(charArray));
                    Esp32Data.Squelch = value;
                } catch (Exception e) {};
            } else if (tag.equals(BT_SPECTRUM_AUTO_PATTERN)) {
                try
                {
                    int value = Integer.parseInt(getNumberInStringFormat(charArray));
                    Esp32Data.DisplayTime = value;
                } catch (Exception e) {};
            }
        }
    }

    static String getNumberInStringFormat(char[] strArray) {
        String nr = "";
        for(int i = 3; i < strArray.length; i++) {
            nr = nr + strArray[i];
        }
        return nr;
    }

    public void write(String s) throws IOException {
        if (outputStream != null && mmDevice != null) {
            try {
                outputStream.write(s.getBytes());
            } catch (IOException e) {
                outputStream = null;
                showToast(e.getMessage());
            }
        } else {
            showToast(btName + ": No conenction");
        }
    }

    public void showToast(String message) {
        try {
            if (toast == null) {
                toast = new Toast(context);
            }
            toast.cancel();
            toast.setText(message);
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.show();
        } catch (Exception e) {
        }
    }
}
